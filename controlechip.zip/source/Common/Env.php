<?php

namespace Source\Common;

function load() {
        
        $dir = "__DIR__.'.env'";

        if(!file_exists($dir)) {
            return false;
        }

        $lines = file($dir);

        return $lines;
    }

